let name = prompt("Ingresa tu nombre");
document.write("Bienvenido " + name);

let valorNeto = 0;

for (let i = 0; i < 5; i + i++) {
    let ventaReal = i;

    valorNeto =
        valorNeto +
        parseInt(prompt("Ingrese valor neto de la venta " + ++ventaReal + ":"));
    if (valorNeto < 0) {
        break;
    }

    if (isNaN(valorNeto)) {
        continue;
    }
}
let porcentajeIva = 0.215;
let valorIva = valorNeto * porcentajeIva;
let valorTotal = valorNeto + valorIva;

alert("Valor IVA " + valorIva);

let resumen = confirm("Querés ver el resumen de tu compra? ");

if (resumen) {
    document.write(
        "Importe sin IVA: " +
        valorNeto +
        " ARS\nMonto IVA: " +
        valorIva +
        " ARS\nTOTAL: " +
        valorTotal +
        " ARS"
    );
}

let bPreguntar = true;

window.onbeforeunload = preguntarAntesDeSalir;

function preguntarAntesDeSalir() {
    let respuesta;

    if (bPreguntar) {
        respuesta = confirm("¿Seguro que quieres salir?");

        if (respuesta) {
            window.onunload = function() {
                return true;
            };
        } else {
            return false;
        }
    }
}